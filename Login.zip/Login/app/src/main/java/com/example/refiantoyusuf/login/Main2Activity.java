package com.example.refiantoyusuf.login;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView nama = (TextView)findViewById(R.id.name);
        nama.setText(getIntent().getStringExtra("usr"));
    }
}
